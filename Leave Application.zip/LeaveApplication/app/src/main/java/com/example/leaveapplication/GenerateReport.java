package com.example.leaveapplication;

import static android.content.ContentValues.TAG;
import static java.util.Objects.requireNonNull;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.pm.PackageManager;
import android.media.MediaScannerConnection;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GenerateReport extends AppCompatActivity {


    private ImageButton frombtn, tobtn;
    private TextView fdate, tdate;
    private Button report;
    private Spinner spinner;
    private String rtype, rfrom, rto, currentmail, runtimeText, fromdate, fromMonth, fromYear, todate, toMonth, toYear;
    private FirebaseAuth mAuth;
    public Map<String, String> mqp3 = new HashMap<>();
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference reference, referenceuser;
    ArrayAdapter<CharSequence> adapter;
    File dir;
    Workbook workbook = new HSSFWorkbook();
    Sheet sheet = workbook.createSheet("Sheet 1");
    private int rowIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.generate_report);


        try {
            requireNonNull(this.getSupportActionBar()).hide();
        } catch (NullPointerException e) {
            Log.d("Action Bar hide", e.getMessage());
        }

        // Request permission to write to external storage
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }
        //firebase

        mAuth = FirebaseAuth.getInstance();
        firebaseDatabase = FirebaseDatabase.getInstance();

        spinner = findViewById(R.id.reportType);
        fdate = findViewById(R.id.fromDate);
        tdate = findViewById(R.id.toDate);
        frombtn = findViewById(R.id.fromcal);
        tobtn = findViewById(R.id.tocal);
        report = findViewById(R.id.btnReport);
        firebaseDatabase = FirebaseDatabase.getInstance();
        reference = firebaseDatabase.getReference("Leave");
        referenceuser = firebaseDatabase.getReference("Users");

        FirebaseUser user = mAuth.getCurrentUser();
        assert user != null;
        currentmail = user.getEmail();

        adapter = ArrayAdapter.createFromResource(this, R.array.ReportType, android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        dir = new File(getExternalFilesDir(null), "Leave_Report");
        //File file = new File(dir,"leavereport.xlsx");
    }

    @Override
    protected void onStart() {
        super.onStart();
        //spinner
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // etype = parent.getItemAtPosition(position).toString();
                rtype = parent.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        //Date picker for from date
        frombtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(GenerateReport.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        String monthtemp = String.format("%02d", month + 1);
                        String daytemp = String.format("%02d", dayOfMonth);
                        fromYear = String.valueOf(year);
                        fromdate = String.valueOf(daytemp);
                        fromMonth = String.valueOf(monthtemp);
                        fdate.setText(year + "/" + monthtemp + "/" + daytemp);
                    }
                }, year, month, day);
                datePickerDialog.show();
            }
        });
        //Date picker for to date
        tobtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);
                DatePickerDialog datePickerDialog = new DatePickerDialog(GenerateReport.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        String monthtemp = String.format("%02d", month + 1);
                        String daytemp = String.format("%02d", dayOfMonth);
                        toYear = String.valueOf(year);
                        todate = String.valueOf(daytemp);
                        toMonth = String.valueOf(monthtemp);
                        tdate.setText(year + "/" + monthtemp + "/" + daytemp);
                    }
                }, year, month, day);
                datePickerDialog.getDatePicker().setMaxDate((System.currentTimeMillis()));
                datePickerDialog.show();
            }
        });


        report.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                exportDataToExcel();

                rtype = spinner.getSelectedItem().toString();
                rfrom = fdate.getText().toString();
                rto = tdate.getText().toString();

//                //create the header row
//                Row headerRow = sheet.createRow(rowIndex++);
//                headerRow.createCell(0).setCellValue("PSN");
//                headerRow.createCell(1).setCellValue("NAME");
//                headerRow.createCell(2).setCellValue("FROM");
//                headerRow.createCell(3).setCellValue("TO");
//                headerRow.createCell(4).setCellValue("No.DAYS");
//                headerRow.createCell(5).setCellValue("CAUSE");

                if (rtype.equals("Daily")) {
                    reference.child("Leaveforleadknown").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()) {
                                for (DataSnapshot sna : snapshot.getChildren()) {
                                    String leadid = sna.getKey();
                                    leadid = leadid.replaceAll("@", "");
                                    leadid = leadid.replaceAll("\\.", "");
                                    String finalLeadid = leadid;
                                    //Log.d("+_", leadid);
                                    reference.child("Leaveforleadknown").child(leadid).addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot snapshot1) {
                                            if (snapshot1.exists()) {
                                                for (DataSnapshot dsd : snapshot1.getChildren()) {
                                                    String empid = dsd.getKey();
                                                    empid = empid.replaceAll("@", "");
                                                    empid = empid.replaceAll("\\.", "");
                                                    String finalempid = empid;
                                                    // Log.d("--",finalLeadid+empid+fromYear+fromMonth);
                                                    reference.child("Leaveforleadknown").child(finalLeadid).child(finalempid).child(fromYear).child(fromMonth).addListenerForSingleValueEvent(new ValueEventListener() {
                                                        @Override
                                                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                            if (snapshot.exists()) {
                                                                if (!dir.exists()) {
                                                                    dir.mkdirs();
                                                                }
                                                                File file = new File(dir, fdate.getText() + ".xlsx");
                                                                Log.d("==", String.valueOf(file));
                                                                for (DataSnapshot snp : snapshot.getChildren()) {
                                                                    int datakey = Integer.parseInt(snp.getKey());
                                                                    int frommonthint = Integer.parseInt(fromdate);
                                                                    int tomonthint = Integer.parseInt(todate);
                                                                    //Log.d("*", fromdate+todate);
                                                                    if (frommonthint <= datakey && tomonthint >= datakey) {
                                                                        Object hashMap = snp.child("Fullday").child("Sick Leave").child("Normal").getValue();
                                                                        Log.d("+=", String.valueOf(hashMap));
                                                                        if (hashMap instanceof HashMap) {
                                                                            HashMap<String, Object> dataMap = (HashMap<String, Object>) hashMap;
                                                                            for(Map.Entry<String,Object>entry : dataMap.entrySet()){
                                                                                String PSN = entry.getKey();
                                                                                String NAME = entry.getKey();
                                                                                String FROM = entry.getKey();
                                                                                String TO = entry.getKey();
                                                                                String No_DAYS = entry.getKey();
                                                                                String CAUSE = entry.getKey();
                                                                                Object psn = entry.getValue();
                                                                                Row dataRow = sheet.createRow(rowIndex++);

                                                                                //FOR key values
                                                                                dataRow.createCell(0).setCellValue(PSN);
                                                                                dataRow.createCell(0).setCellValue(NAME);
                                                                                dataRow.createCell(0).setCellValue(FROM);
                                                                                dataRow.createCell(0).setCellValue(TO);
                                                                                dataRow.createCell(0).setCellValue(No_DAYS);
                                                                                dataRow.createCell(0).setCellValue(CAUSE);
                                                                                Log.d("ee", String.valueOf(dataRow));

                                                                                //for Values
                                                                                dataRow.createCell(1).setCellValue(psn.toString());

                                                                            }
//                                                                            Row dataRow = sheet.createRow(rowIndex++);
//                                                                            dataRow.createCell(0).setCellValue(dataMap.get("PSN").toString());
//                                                                            dataRow.createCell(1).setCellValue(dataMap.get("NAME").toString());
//                                                                            dataRow.createCell(2).setCellValue(dataMap.get("FROM").toString());
//                                                                            dataRow.createCell(3).setCellValue(dataMap.get("TO").toString());
//                                                                            dataRow.createCell(4).setCellValue(dataMap.get("No.DAYS").toString());
//                                                                            dataRow.createCell(5).setCellValue(dataMap.get("CAUSE").toString());
                                                                        }
                                                                        saveExcelFile(workbook);
                                                                    }
                                                                }
                                                                try {
                                                                    OutputStream outputStream = new FileOutputStream(file);
                                                                    workbook.write(outputStream);
                                                                    outputStream.flush();
                                                                    outputStream.close();
                                                                    //Toast.makeText(getApplicationContext(),"Excel file is create successfully",Toast.LENGTH_LONG).show();
                                                                    Log.d(TAG, "Excel file saved to " + file.getAbsolutePath());
                                                                } catch (IOException e) {
                                                                    Log.d("00",e.getMessage());
                                                                    e.printStackTrace();
                                                                }
                                                            }
                                                        }

                                                        @Override
                                                        public void onCancelled(@NonNull DatabaseError error) {
                                                            Log.e("TAG", "Database error: " + error.getMessage());
                                                        }
                                                    });
                                                }
                                            }
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError error) {
                                            Log.e("TAG", "Database error: " + error.getMessage());
                                        }
                                    });
                                }
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Log.e("TAG", "Database error: " + error.getMessage());
                        }
                    });

                } else if (rtype.equals("Weekly")) {

                } else if (rtype.equals("Monthly")) {

                } else if (rtype.equals("Yearly")) {

                }
            }
        });
    }

    private void saveExcelFile(Workbook workbook) {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            return;
        }
        // Create the file path
        String fileName = fdate.getText().toString() + ".xlsx";
        File file = new File(dir, fileName);
        try {
            FileOutputStream fileOut = new FileOutputStream(file);
            workbook.write(fileOut);
            fileOut.close();
            Log.d("--","Excel file updated and saved successfully");

            MediaScannerConnection.scanFile(GenerateReport.this, new String[]{file.getAbsolutePath()}, null, null);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(GenerateReport.this, "Excel file downloaded", Toast.LENGTH_SHORT).show();
                    Log.d("-9", String.valueOf(workbook));
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Create the directory if it doesn't exist
        if(!dir.exists()) {
            dir.mkdirs();
        }


    }
}
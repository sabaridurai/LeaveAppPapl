public abstract class NavActivity  {
}
